KSQora — Creator Hammer Icon

This ZIP contains the custom yellow hammer Vector Drawable.

1. Copy the android/ folder into the root of your KSQora repository, merging folders.
2. In MainActivity.kt, add:
   import androidx.compose.foundation.Image
   import androidx.compose.ui.res.painterResource
3. Replace the old creator emoji/text badge with the Compose snippet below:

Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(6.dp),
    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
) {
    Image(
        painter = painterResource(R.drawable.ic_creator_hammer),
        contentDescription = "Yaradıcı çəkici",
        modifier = Modifier.size(19.dp)
    )
    Text(
        "Yaradıcı",
        color = Yellow,
        fontWeight = FontWeight.Bold
    )
}

Required existing Compose imports may include:
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material3.Text

Note: This ZIP adds the drawable resource; it does not modify MainActivity.kt or build an APK.
