package com.ksqora.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Ink = Color(0xFF17152A)
private val Purple = Color(0xFF6C55E8)
private val Canvas = Color(0xFFF5F4FA)
private val subjects = listOf(
    "Azərbaycan dili", "Riyaziyyat", "Ədəbiyyat", "Fizika", "Texnologiya",
    "Kimya", "İnformatika", "Biologiya", "İngilis dili", "Rus dili"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KSQoraApp() }
    }
}

data class Question(val text: String, val options: List<String>, val correct: Int)
data class Exam(val id: Long, val title: String, val subject: String, val questions: List<Question>)

@Composable
fun KSQoraApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ksqora", 0) }
    var userName by remember { mutableStateOf(prefs.getString("name", "") ?: "") }
    var userEmail by remember { mutableStateOf(prefs.getString("email", "") ?: "") }
    var signedIn by remember { mutableStateOf(userName.isNotBlank() && userEmail.isNotBlank()) }
    var page by remember { mutableStateOf("home") }
    var exams by remember { mutableStateOf(loadExams(prefs.getString("exams", "[]") ?: "[]")) }
    var selectedExam by remember { mutableStateOf<Exam?>(null) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Purple, onPrimary = Color.White, background = Canvas,
            surface = Color.White, onSurface = Ink
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Canvas) {
            if (!signedIn) {
                LoginScreen(
                    name = userName, email = userEmail,
                    onName = { userName = it }, onEmail = { userEmail = it },
                    onContinue = {
                        if (userName.isNotBlank() && userEmail.contains("@")) {
                            prefs.edit().putString("name", userName.trim())
                                .putString("email", userEmail.trim()).apply()
                            signedIn = true
                        }
                    }
                )
            } else {
                Column(Modifier.fillMaxSize()) {
                    Header(userName)
                    when (page) {
                        "create" -> CreateExamScreen(onSave = { exam ->
                            exams = exams + exam
                            prefs.edit().putString("exams", saveExams(exams)).apply()
                            page = "mine"
                        }, onBack = { page = "home" })
                        "student" -> StudentScreen(exams, onOpen = {
                            selectedExam = it
                            page = "solve"
                        }, onBack = { page = "home" })
                        "mine" -> MyExamsScreen(exams, onShare = { exam ->
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, encodeExam(exam))
                            }
                            context.startActivity(Intent.createChooser(send, "KSQ paylaş"))
                        }, onDelete = { id ->
                            exams = exams.filterNot { it.id == id }
                            prefs.edit().putString("exams", saveExams(exams)).apply()
                        }, onBack = { page = "home" })
                        "solve" -> selectedExam?.let { SolveScreen(it, onBack = { page = "student" }) }
                        "settings" -> SettingsScreen(userName, userEmail, onSignOut = {
                            prefs.edit().remove("name").remove("email").apply()
                            userName = ""; userEmail = ""; signedIn = false
                        }, onBack = { page = "home" })
                        else -> HomeScreen(
                            examCount = exams.size,
                            onCreate = { page = "create" },
                            onStudent = { page = "student" },
                            onMine = { page = "mine" },
                            onSettings = { page = "settings" }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(name: String) {
    Row(
        Modifier.fillMaxWidth().background(Ink).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("KSQora", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text("Təhsil üçün ağıllı KSQ platforması", color = Color(0xFFBEB9D5), fontSize = 12.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(name, color = Color.White, fontWeight = FontWeight.SemiBold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Gavel, null, tint = Color(0xFFFFD34F), modifier = Modifier.size(14.dp))
                Text(" Yaradıcı", color = Color(0xFFFFD34F), fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun LoginScreen(
    name: String, email: String, onName: (String) -> Unit,
    onEmail: (String) -> Unit, onContinue: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("KSQora", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Ink)
        Text("Hesabına daxil ol", color = Color.Gray, modifier = Modifier.padding(bottom = 24.dp))
        OutlinedTextField(name, onName, label = { Text("Ad və soyad") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            email, onEmail, label = { Text("E-poçt") }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )
        Spacer(Modifier.height(18.dp))
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Text("Davam et")
        }
        Text("Bu ilkin versiyada profil məlumatları yalnız cihazda saxlanılır.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
private fun HomeScreen(
    examCount: Int, onCreate: () -> Unit, onStudent: () -> Unit,
    onMine: () -> Unit, onSettings: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Xoş gəldin!", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text("Bu gün hansı işi görürük?", color = Color.Gray)
        Spacer(Modifier.height(20.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Ink), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(22.dp)) {
                Text("KSQ-larını asanlıqla hazırla", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Yarat, paylaş və nəticələri yoxla.", color = Color(0xFFD2CDEA), modifier = Modifier.padding(top = 6.dp))
                Text("$examCount saxlanılmış KSQ", color = Color(0xFFFFD34F), modifier = Modifier.padding(top = 18.dp))
            }
        }
        Spacer(Modifier.height(18.dp))
        ActionCard("KSQ yarat", "Müəllim üçün yeni qiymətləndirmə", Icons.Default.Add, onCreate)
        ActionCard("KSQ həll et", "Paylaşılan KSQ-lara bax", Icons.Default.Edit, onStudent)
        ActionCard("Mənim KSQ-larım", "Yaratdıqlarını idarə et", Icons.Default.Folder, onMine)
        ActionCard("Ayarlar", "Profil və tətbiq məlumatları", Icons.Default.Settings, onSettings)
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, click: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { click() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Purple, modifier = Modifier.size(28.dp))
            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                Text(title, fontWeight = FontWeight.Bold, color = Ink)
                Text(subtitle, color = Color.Gray, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
        }
    }
}

@Composable
private fun CreateExamScreen(onSave: (Exam) -> Unit, onBack: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf(subjects.first()) }
    var questionText by remember { mutableStateOf("") }
    var options by remember { mutableStateOf(listOf("", "", "", "")) }
    var correct by remember { mutableIntStateOf(0) }
    var questions by remember { mutableStateOf(listOf<Question>()) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        PageTop("KSQ yarat", onBack)
        LazyColumn {
            item {
                OutlinedTextField(title, { title = it }, label = { Text("KSQ adı") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded, { expanded = it }) {
                    OutlinedTextField(subject, {}, readOnly = true, label = { Text("Fənn") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded, { expanded = false }) {
                        subjects.forEach { s -> DropdownMenuItem(text = { Text(s) }, onClick = { subject = s; expanded = false }) }
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text("Sual ${questions.size + 1}", fontWeight = FontWeight.Bold)
                OutlinedTextField(questionText, { questionText = it }, label = { Text("Sualın mətni") }, modifier = Modifier.fillMaxWidth())
                options.forEachIndexed { i, value ->
                    OutlinedTextField(value, { v -> options = options.toMutableList().also { it[i] = v } }, label = { Text("Variant ${'A' + i}") }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp))
                }
                Text("Düzgün cavab", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    options.indices.forEach { i ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            RadioButton(selected = correct == i, onClick = { correct = i })
                            Text("${'A' + i}")
                        }
                    }
                }
                OutlinedButton(
                    onClick = {
                        if (questionText.isNotBlank() && options.all { it.isNotBlank() }) {
                            questions = questions + Question(questionText.trim(), options.map { it.trim() }, correct)
                            questionText = ""; options = listOf("", "", "", ""); correct = 0
                        }
                    }, modifier = Modifier.fillMaxWidth()
                ) { Text("Sualı əlavə et") }
                Text("${questions.size} sual əlavə olunub", color = Purple, modifier = Modifier.padding(vertical = 10.dp))
                Button(
                    onClick = { if (title.isNotBlank() && questions.isNotEmpty()) onSave(Exam(System.currentTimeMillis(), title.trim(), subject, questions)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("KSQ-nı yadda saxla") }
            }
        }
    }
}

@Composable
private fun StudentScreen(exams: List<Exam>, onOpen: (Exam) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        PageTop("KSQ həll et", onBack)
        if (exams.isEmpty()) Text("Hələ paylaşılmış və ya saxlanılmış KSQ yoxdur.", color = Color.Gray)
        LazyColumn {
            items(exams) { exam ->
                ActionCard("${exam.title} · ${exam.subject}", "${exam.questions.size} sual", Icons.Default.Assignment, { onOpen(exam) })
            }
        }
    }
}

@Composable
private fun MyExamsScreen(exams: List<Exam>, onShare: (Exam) -> Unit, onDelete: (Long) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        PageTop("Mənim KSQ-larım", onBack)
        if (exams.isEmpty()) Text("Hələ KSQ yaratmamısan.", color = Color.Gray)
        LazyColumn {
            items(exams, key = { it.id }) { exam ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(15.dp)) {
                        Text(exam.title, fontWeight = FontWeight.Bold)
                        Text("${exam.subject} · ${exam.questions.size} sual", color = Color.Gray, fontSize = 12.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { onShare(exam) }) { Text("Paylaş") }
                            TextButton(onClick = { onDelete(exam.id) }, colors = ButtonDefaults.textButtonColors(contentColor = Color.Red)) { Text("Sil") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SolveScreen(exam: Exam, onBack: () -> Unit) {
    var answers by remember(exam.id) { mutableStateOf(mapOf<Int, Int>()) }
    var submitted by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        PageTop(exam.title, onBack)
        LazyColumn {
            items(exam.questions.size) { index ->
                val q = exam.questions[index]
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("${index + 1}. ${q.text}", fontWeight = FontWeight.Bold)
                        q.options.forEachIndexed { option, text ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(answers[index] == option, { answers = answers + (index to option) }, enabled = !submitted)
                                Text("${'A' + option}. $text")
                            }
                        }
                    }
                }
            }
            item {
                Button(onClick = { submitted = true }, enabled = !submitted && answers.size == exam.questions.size, modifier = Modifier.fillMaxWidth()) {
                    Text("Cavabları yoxla")
                }
                if (submitted) {
                    val score = exam.questions.indices.count { answers[it] == exam.questions[it].correct }
                    Text("Nəticə: $score / ${exam.questions.size}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Purple, modifier = Modifier.padding(16.dp))
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(name: String, email: String, onSignOut: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        PageTop("Ayarlar", onBack)
        Text("Profil", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(name, modifier = Modifier.padding(top = 12.dp))
        Text(email, color = Color.Gray)
        Spacer(Modifier.height(20.dp))
        Text("Hesabdan çıxış bu cihazda saxlanılan profil məlumatlarını silir.", color = Color.Gray)
        Button(onClick = onSignOut, modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) { Text("Hesabdan çıx") }
    }
}

@Composable
private fun PageTop(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Geri") }
        Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
    }
}

private fun saveExams(exams: List<Exam>): String {
    val arr = JSONArray()
    exams.forEach { e ->
        val qs = JSONArray()
        e.questions.forEach { q ->
            qs.put(JSONObject().put("text", q.text).put("options", JSONArray(q.options)).put("correct", q.correct))
        }
        arr.put(JSONObject().put("id", e.id).put("title", e.title).put("subject", e.subject).put("questions", qs))
    }
    return arr.toString()
}

private fun loadExams(raw: String): List<Exam> = try {
    val arr = JSONArray(raw)
    (0 until arr.length()).map { i ->
        val e = arr.getJSONObject(i)
        val qs = e.getJSONArray("questions")
        val questions = (0 until qs.length()).map { j ->
            val q = qs.getJSONObject(j); val opts = q.getJSONArray("options")
            Question(q.getString("text"), (0 until opts.length()).map { opts.getString(it) }, q.getInt("correct"))
        }
        Exam(e.getLong("id"), e.getString("title"), e.getString("subject"), questions)
    }
} catch (_: Exception) { emptyList() }

private fun encodeExam(exam: Exam): String = android.util.Base64.encodeToString(
    JSONObject().put("title", exam.title).put("subject", exam.subject).put("data", saveExams(listOf(exam))).toString().toByteArray(),
    android.util.Base64.NO_WRAP
)
