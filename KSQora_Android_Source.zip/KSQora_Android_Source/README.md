# KSQora Android

Native Android project built with Kotlin and Jetpack Compose.

## Features in this source package
- Profile screen using name + email (local demo profile; no server authentication)
- Teacher flow: create KSQ with 4 options and select the correct answer
- Ten Azerbaijani school subjects
- Student flow: answer questions and see score
- My KSQs: share via Android share sheet and delete
- Settings and creator label with a drawn hammer icon

## Build
Open this folder in Android Studio, allow Gradle sync, then run:
`./gradlew assembleDebug`

The debug APK is generated at:
`app/build/outputs/apk/debug/app-debug.apk`

A Gradle wrapper is not included. Android Studio can generate/download the wrapper on first project setup, or use the installed Gradle distribution.

## Important
This is an offline starter build. Name/email are stored locally; there is no real email verification, cloud account system, teacher/student backend, or public share-link hosting yet. Sharing currently uses Android's share sheet and a text payload.
